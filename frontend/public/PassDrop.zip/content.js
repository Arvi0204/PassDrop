(function(){"use strict";const F=["text","email","tel"],D=new WeakMap,W=t=>(D.get(t)??t.getAttribute("autocomplete")??"").toLowerCase().split(/\s+/),f=(t,n)=>W(t).includes(n);function G(t){const n=t.ownerDocument.defaultView;for(let o=t;o&&o.nodeType===1;o=o.parentElement){const r=n.getComputedStyle(o);if(r.display==="none"||r.visibility==="hidden"||r.visibility==="collapse"||Number(r.opacity)===0)return!1}const e=t.getBoundingClientRect();return!(e.width<4||e.height<4||e.right+n.scrollX<=0||e.bottom+n.scrollY<=0)}const V=t=>t.getAttribute("role")==="searchbox"||/search/i.test(`${t.name} ${t.id} ${t.placeholder} ${t.getAttribute("aria-label")||""}`);function q(t){const n=t.filter(o=>f(o,"username")||f(o,"email"));return(n.length?n:t).at(-1)??null}function S(t,{isVisible:n=G}={}){const e=t.defaultView.Node.DOCUMENT_POSITION_FOLLOWING,o=s=>!s.disabled&&!s.readOnly&&n(s),r=[...t.querySelectorAll("input")],a=r.filter(s=>s.type==="password"&&o(s)),l=r.filter(s=>F.includes(s.type)&&o(s)&&!V(s)),g=new Map;for(const s of a)g.set(s.form,[...g.get(s.form)||[],s]);let w=!1;for(const[s,b]of g){if(b.length>1||b.some(u=>f(u,"new-password"))){w=!0;continue}const[d]=b,N=l.filter(u=>u.form===s&&u.compareDocumentPosition(d)&e);return{status:"ok",username:q(N),password:d}}if(w)return{status:"signup"};const h=l.filter(s=>f(s,"username")||f(s,"email"));return h.length===1?{status:"ok",username:h[0],password:null}:{status:"none"}}function I(t,n){var r;const e=t.ownerDocument.defaultView,o=(r=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(t),"value"))==null?void 0:r.set;t.focus(),o?o.call(t,n):t.value=n,t.dispatchEvent(new e.Event("input",{bubbles:!0})),t.dispatchEvent(new e.Event("change",{bubbles:!0}))}function U(t,{username:n,password:e}){var r;const o=[];return t.username&&n&&(I(t.username,n),o.push("username")),t.password&&e&&(I(t.password,e),o.push("password")),(r=t.password||t.username)==null||r.focus(),o}const j=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60" fill="none">\r
    <defs>\r
        <linearGradient id="drop-g1" x1="0.1" y1="0" x2="0.9" y2="1">\r
            <stop offset="0%" stop-color="#0077b6" />\r
            <stop offset="100%" stop-color="#0284c7" />\r
        </linearGradient>\r
        <linearGradient id="drop-g2" x1="0.1" y1="0" x2="0.9" y2="1">\r
            <stop offset="0%" stop-color="#00b4d8" />\r
            <stop offset="100%" stop-color="#48cae4" />\r
        </linearGradient>\r
    </defs>\r
    <!-- Primary Drop (Vault / Storage) -->\r
    <path\r
        d="M22 2C22 2 4 18 4 30A18 18 0 0 0 40 30C40 18 22 2 22 2Z"\r
        fill="url(#drop-g1)"\r
    />\r
    <!-- Secondary Intersecting Drop (Sharing / Ephemeral) -->\r
    <path\r
        d="M40 16C40 16 24 30 24 40A16 16 0 0 0 56 40C56 30 40 16 40 16Z"\r
        fill="url(#drop-g2)"\r
        opacity="0.92"\r
    />\r
</svg>\r
`,B=`
  :host { all: initial; }
  .menu { box-sizing: border-box; font: 14px/1.35 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; color: #0c1820;
    background: linear-gradient(to top, #fff1eb 0%, #ace0f9 100%); border: 1px solid rgba(255, 255, 255, .95);
    border-radius: 18px; padding: 10px; box-shadow: 0 16px 36px -10px rgba(17, 40, 56, .45); -webkit-font-smoothing: antialiased; }
  .brand { display: flex; align-items: center; gap: 8px; padding: 6px 10px 10px; font-weight: 800; font-size: 14px; letter-spacing: -.01em; }
  .brand svg { width: 22px; height: 22px; }
  .brand b { color: #0284c7; }
  .rows { display: grid; gap: 4px; }
  button { all: unset; box-sizing: border-box; display: flex; align-items: center; gap: 12px; width: 100%; padding: 10px 12px;
    border-radius: 13px; cursor: pointer; transition: background .15s; }
  button:hover { background: rgba(255, 255, 255, .6); }
  button:focus-visible { background: rgba(255, 255, 255, .75); outline: 2px solid #0284c7; outline-offset: -2px; }
  .avatar { flex: none; width: 36px; height: 36px; box-sizing: border-box; border-radius: 12px; display: grid; place-items: center;
    background: #e0f2fe; color: #0369a1; font-weight: 800; font-size: 14px; overflow: hidden; }
  .avatar.icon { background: #fff; border: 1px solid rgba(17, 40, 56, .1); padding: 5px; }
  .avatar img { width: 100%; height: 100%; object-fit: contain; }
  .t { min-width: 0; flex: 1; }
  strong { display: block; font-weight: 700; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  span.u { display: block; margin-top: 2px; color: #3a5566; font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  p { margin: 0; padding: 2px 10px 10px; color: #3a5566; font-size: 13px; }
`;let i=null,C=!1;const L=async t=>{try{return await chrome.runtime.sendMessage(t)}catch{return null}};let y=!1;const P=new WeakSet;function z(t){P.has(t)||(P.add(t),D.set(t,t.getAttribute("autocomplete")??""),t.setAttribute("autocomplete","off"))}let k=null,m=0;const c=()=>{m++,i==null||i.close()},R=()=>{var t;return((t=document.querySelector('link[rel~="icon" i][href]'))==null?void 0:t.href)||`${location.origin}/favicon.ico`};function Y(t,n){const e=new Image;e.alt="",e.addEventListener("load",()=>{t.classList.add("icon"),t.replaceChildren(e)},{once:!0}),e.src=n}function H(t,n){const e=document.createElement("div"),o=e.attachShadow({mode:"closed"}),r=document.createElement("style");r.textContent=B;const a=document.createElement("div");a.className="menu",a.setAttribute("role","menu");const l=document.createElement("div");l.className="brand";const g=new DOMParser().parseFromString(j,"image/svg+xml").documentElement,w=document.createElement("span"),h=document.createElement("b");if(h.textContent="Drop",w.append("Pass",h),l.append(document.importNode(g,!0),w),a.append(l),n){const p=document.createElement("div");p.className="rows",a.append(p);const _=R();for(const v of n){const x=document.createElement("button");x.type="button",x.setAttribute("role","menuitem");const E=document.createElement("span");E.className="avatar",E.textContent=v.title.charAt(0).toUpperCase(),Y(E,_);const O=document.createElement("span");O.className="t";const $=document.createElement("strong");$.textContent=v.title;const A=document.createElement("span");A.className="u",A.textContent=v.username||"No username",O.append($,A),x.append(E,O),x.addEventListener("click",Z=>{Z.isTrusted&&X(v.id)}),p.append(x)}}else{const p=document.createElement("p");p.textContent="Sign in from the PassDrop toolbar icon to fill your logins here.",a.append(p)}o.append(r,a);const s=t.getBoundingClientRect();Object.assign(e.style,{position:"absolute",zIndex:"2147483647",minWidth:`${Math.max(s.width,280)}px`,maxWidth:"380px"}),document.documentElement.append(e);const{width:b,height:d}=e.getBoundingClientRect(),N=window.innerHeight-s.bottom>=d+8||s.top<d+8,u=Math.max(8,Math.min(s.left,window.innerWidth-b-8));e.style.left=`${u+window.scrollX}px`,e.style.top=`${(N?s.bottom+8:s.top-d-8)+window.scrollY}px`,i={host:e,anchor:t,root:o,close:()=>{e.remove(),i=null}}}async function X(t){const n=++m,e=await L({type:"credentials",id:t});if(n!==m||!(e!=null&&e.ok))return;c();const o=S(document);if(o.status==="ok"){C=!0;try{U(o,e)}finally{C=!1}}}async function T(t){const n=t.target;if(C||(i==null?void 0:i.anchor)===n||(c(),!(n instanceof HTMLInputElement)))return;const e=S(document);if(e.status!=="ok"||n!==e.username&&n!==e.password||(y&&z(n),k===n))return;k=n;const o=m,r=await L({type:"logins"});k===n&&(k=null),!(o!==m||!r)&&(y=r.ok?r.logins.length>0:r.code==="auth",y&&(z(n),H(n,r.ok?r.logins:null)))}(async()=>{if(S(document).status!=="ok")return;const t=await L({type:"logins"});y=!!t&&(t.ok?t.logins.length>0:t.code==="auth")})();const M=t=>!!i&&t.composedPath().includes(i.host);document.addEventListener("focusin",t=>{M(t)||T(t)},!0),document.addEventListener("click",t=>{M(t)||T(t)},!0),document.addEventListener("mousedown",t=>{i&&!M(t)&&t.target!==i.anchor&&c()},!0),document.addEventListener("keydown",t=>{var n;if(i)if(t.key==="Escape"){const e=i.anchor;c(),e.focus()}else t.key==="ArrowDown"&&t.target===i.anchor&&(t.preventDefault(),(n=i.root.querySelector("button"))==null||n.focus())},!0),window.addEventListener("scroll",c,{passive:!0}),window.addEventListener("resize",c)})();
